<?php

interface IQuery
{
    // public static function selectAll();
    // public static function select($id);
    // public static function insert();
    // public static function update($id);
    // public static function delete($id);

}


?>