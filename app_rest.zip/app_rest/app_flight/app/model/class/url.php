<?php

class Url {
	
	public $Version = null;
	public $Category = null;
	public $Class = null;
	public $Id = null;
	
	public function __construct() {
	}
}

?>