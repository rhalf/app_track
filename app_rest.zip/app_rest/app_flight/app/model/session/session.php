<?php 

class Session {

	public function __construct() {
	}

	public static function login( $username, $password) {

		$connection = Flight::dbMain();

		try {
			$connection = Flight::dbMain();



			if ($username != NULL && $password != NULL) {

				$sql = "SELECT * FROM user WHERE user.user_name = :name and user.user_password = :password;";
				$query = $connection->prepare($sql);

				$query->bindParam(':name',$username, PDO::PARAM_STR);
				$query->bindParam(':password',$password, PDO::PARAM_STR);

			} else {
				throw new Exception("Username or Password is not set");
			}

			$query->execute();

			$result = new Result();
			$result->Item = $query->rowCount();
			$result->Object = array();

			$rows = $query->fetch(PDO::FETCH_ASSOC);


			if ($query->rowCount() > 0) {

				$user = new User();
				$user->Id = (int) $row['id'];
				$user->Name = $row['user_name'];
				$user->Password = $row['user_password'];
				$user->Hash = $row['user_hash'];
				$user->DtCreated = $row['user_dt_created'];
				$user->DtExpired = $row['user_dt_expired'];
				$user->DtLogin = $row['user_dt_login'];
				$user->DtActive = $row['user_dt_active'];
				$user->Privilege = (int) $row['e_privilege_id'];
				$user->Status = (int) $row['e_status_id'];
				$user->Company = (int) $row['company_id'];
				$user->Info = (int) $row['user_info_id'];

				$result->Status = Result::SUCCESS;
				$result->Message = 'Done.';

				array_push($result->Object, $user);

			} else {
				throw new Exception("Unknown username and/or password");
			}

		} catch (PDOException $pdoException) {

			$result = new Result();
			$result->Status = Result::ERROR;
			$result->Message = $pdoException->getMessage();

		} catch (Exception $exception) {
			
			$result = new Result();
			$result->Status = Result::ERROR;
			$result->Message = $exception->getMessage();
		}

		$connection = null;

		return $result;
	}

	public static function logout() {
		
		$connection = Flight::dbMain();

		try {

			// $sql = "
			// DELETE FROM user 
			// WHERE
			// id = :id";

			// $query = $connection->prepare($sql);

			// $query->bindParam(':id', $id, PDO::PARAM_INT);

			// $query->execute();

			$result = new Result();
			$result->Status = Result::SUCCESS;
			$result->Message = 'Done';
			$result->Id = $id;

			Flight::ok($result);

		} catch (PDOException $pdoException) {
			Flight::error($pdoException);
		} catch (Exception $exception) {
			Flight::error($exception);
		} finally {
			$connection = null;
		}

	}
}

?>